package com.jiangnan;


import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class App1Test {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testA() throws Exception {
		assertTrue(true);
	}
	@Test
	public void testB() throws Exception {
		assertFalse(true);
		
	}

}
