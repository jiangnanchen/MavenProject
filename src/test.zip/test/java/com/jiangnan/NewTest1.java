package com.jiangnan;

import org.testng.annotations.Test;
import static org.testng.Assert.*;
public class NewTest1 {
  @Test
  public void f() {
	  assertTrue(true);
  }

}
